/**
 * PoE Trade Companion — 官网市集页面汉化（通道 B：DOM 层）
 *
 * 设计要点：
 *  - TreeWalker 遍历文本节点 + MutationObserver 监听动态插入，只处理文本节点，不改任何节点结构
 *  - 原文快照存 WeakMap，还原时逐节点写回，保证「关闭汉化」后与原始页面完全一致
 *  - 幂等：同一文本节点用记录的最后输出值比对，未变则跳过；自身改写不会触发二次改写
 *  - 跳过 script/style/noscript/textarea/code/pre、扩展自身容器（#ptc-root）与 [data-ptc-skip]
 */
(function () {
  'use strict';

  var SELF = (window.PTC = window.PTC || {});

  var SKIP_TAGS = {
    SCRIPT: 1,
    STYLE: 1,
    NOSCRIPT: 1,
    TEXTAREA: 1,
    CODE: 1,
    PRE: 1,
    IFRAME: 1,
    SVG: 1,
    CANVAS: 1,
    INPUT: 1,
    SELECT: 1
  };

  var SKIP_CLASS = ['ptc-panel', 'ptc-tooltip'];
  var SKIP_SELECTOR = '#ptc-root, [data-ptc-skip], .ptc-panel, .ptc-tooltip, .ptc-badge, .ptc-toast';

  var state = {
    enabled: false,
    level: 'ui',
    patterns: true,
    dict: {},        // 合并后的生效词典（原始大小写）
    dictLower: {},   // 小写索引兜底
    byId: {},
    patternsList: [],
    records: new WeakMap(), // textNode -> { origin, output }
    attrRecords: new WeakMap(), // element -> { attrName: { origin, output } }
    observer: null,
    applying: false,
    stats: { nodes: 0, translated: 0 }
  };

  // 参与汉化的属性；input 的 value 一律不处理，避免破坏表单值与提交参数
  var ATTRS = ['placeholder', 'title', 'aria-label'];
  // 单批处理上限（requestIdleCallback 分片，避免主线程长任务卡顿搜索页）
  var BATCH_LIMIT = 500;

  function normalize(str) {
    return String(str).replace(/[\s\u00a0]+/g, ' ').trim();
  }

  /** 纯英文文本判定：含 CJK 或完全无字母则跳过 */
  function isCandidate(text) {
    if (!text) return false;
    if (/[\u4e00-\u9fff]/.test(text)) return false;      // 已含中文
    return /[A-Za-z]{2}/.test(text);
  }

  /** 精确 → 小写兜底 → 正则模板 */
  function translate(raw) {
    var text = String(raw);
    var lead = text.match(/^\s*/)[0];
    var trail = text.match(/\s*$/)[0];
    var core = normalize(text);
    if (!core) return null;

    var hit = state.dict[core];
    if (hit !== undefined) return lead + hit + trail;

    var low = core.toLowerCase();
    hit = state.dictLower[low];
    if (hit !== undefined) return lead + hit + trail;

    if (state.patterns) {
      for (var i = 0; i < state.patternsList.length; i++) {
        var p = state.patternsList[i];
        var m = core.match(p.re);
        if (m) {
          // 兼容内置（fn 函数）与远端（replace 字符串）两种模板
          if (typeof p.fn === 'function') return lead + p.fn(m) + trail;
          if (typeof p.replace === 'string') {
            return lead + core.replace(p.re, p.replace) + trail;
          }
        }
      }
    }
    return null;
  }

  /** 数据层按 id 精确定位改写用的查询入口（供 options 预览/调试） */
  function lookupById(id) {
    return state.byId[id] || null;
  }

  /**
   * 设置词典与开关。
   * 词典优先级：用户自定义 > 远端配置 > 内置；
   * zhLevel='ui' 只用界面级词库（uiDict），'full' 用全量（dict，含物品名与词缀）。
   * @param {{enabled:boolean, level:'ui'|'full', patterns:boolean,
   *          dict:Object, uiDict:Object, fullDict:Object, userDict:Object,
   *          patternsList:Array, byId:Object}} opt
   */
  function configure(opt) {
    opt = opt || {};
    var full = opt.level === 'full';
    var sources = full
      ? [opt.uiDict || {}, opt.fullDict || {}, opt.dict || {}]
      : [opt.uiDict || opt.dict || {}];
    sources.push(opt.remoteDict || {});
    sources.push(opt.userDict || {});

    var merged = {};
    for (var i = 0; i < sources.length; i++) {
      var src = sources[i];
      for (var k in src) {
        if (Object.prototype.hasOwnProperty.call(src, k) && typeof src[k] === 'string' && src[k]) merged[k] = src[k];
      }
    }
    var lower = {};
    for (var key in merged) lower[key.toLowerCase()] = merged[key];

    state.dict = merged;
    state.dictLower = lower;
    state.byId = opt.byId || {};
    state.patternsList = Array.isArray(opt.patternsList) ? opt.patternsList : [];
    state.level = full ? 'full' : 'ui';
    state.patterns = opt.patterns !== false;

    var wasEnabled = state.enabled;
    state.enabled = !!opt.enabled;

    if (!state.enabled && wasEnabled) restore();
    if (state.enabled) {
      start();
      applyAll();
    }
    return summary();
  }

  function shouldSkipElement(el) {
    if (!el || el.nodeType !== 1) return false;
    if (SKIP_TAGS[el.tagName]) return true;
    for (var i = 0; i < SKIP_CLASS.length; i++) {
      if (el.classList && el.classList.contains(SKIP_CLASS[i])) return true;
    }
    if (el.id === 'ptc-root') return true;
    if (el.getAttribute && el.getAttribute('data-ptc-skip') === '1') return true;
    if (el.isContentEditable) return true;
    return false;
  }

  function warnSkipped(el) {
    // 子元素整体跳过时（如 svg 内的 title）直接返回 true
    return !!(el.closest && el.closest(SKIP_SELECTOR));
  }

  /** 文本节点汉化：原文快照存 WeakMap，页面自行改写的文本视为新原文 */
  function translateNode(node) {
    var origin = state.records.get(node);
    var current = node.nodeValue;
    if (origin && current !== origin.output) {
      origin = { origin: current, output: current };
      state.records.set(node, origin);
    }
    var base = origin ? origin.origin : current;
    if (!isCandidate(base)) {
      if (!origin) state.records.set(node, { origin: current, output: current });
      return false;
    }
    var zh = translate(base);
    if (zh === null) {
      if (!origin) state.records.set(node, { origin: current, output: current });
      return false;
    }
    if (current !== zh) node.nodeValue = zh;
    // 标记父元素，便于样式/排查与后续按块还原
    var host = node.parentElement;
    if (host && host.setAttribute) {
      try {
        host.setAttribute('data-ptc-zh', '1');
      } catch (e) {
        /* ignore */
      }
    }
    state.records.set(node, { origin: base, output: zh });
    state.stats.translated += 1;
    return true;
  }

  /** 单个属性汉化（placeholder / title / aria-label；不触碰 value） */
  function translateAttr(el, name) {
    var raw = el.getAttribute(name);
    if (raw === null || raw === '' || !isCandidate(raw)) return false;
    var store = state.attrRecords.get(el);
    if (!store) {
      store = {};
      state.attrRecords.set(el, store);
    }
    var rec = store[name];
    if (rec && raw !== rec.output) rec = store[name] = { origin: raw, output: raw };
    var base = rec ? rec.origin : raw;
    var zh = translate(base);
    if (zh === null) {
      if (!rec) store[name] = { origin: raw, output: raw };
      return false;
    }
    if (raw !== zh) el.setAttribute(name, zh);
    store[name] = { origin: base, output: zh };
    state.stats.translated += 1;
    return true;
  }

  function translateAttrs(el) {
    var n = 0;
    for (var i = 0; i < ATTRS.length; i++) {
      if (el.hasAttribute && el.hasAttribute(ATTRS[i]) && translateAttr(el, ATTRS[i])) n += 1;
    }
    return n;
  }

  /** 采集一次：把 root 下所有可汉化项（文本节点 + 属性）扁平化入队，供分片处理 */
  function collect(root, out) {
    if (!root) return out;
    if (root.nodeType === 3) {
      var tp = root.parentElement;
      if (tp && !shouldSkipElement(tp) && !warnSkipped(tp)) out.push({ node: root });
      return out;
    }
    if (root.nodeType !== 1 || shouldSkipElement(root) || warnSkipped(root)) return out;

    if (root.hasAttribute) out.push({ el: root });

    var els = root.querySelectorAll ? root.querySelectorAll('[placeholder], [title], [aria-label]') : [];
    for (var e = 0; e < els.length; e++) {
      var el = els[e];
      if (shouldSkipElement(el) || warnSkipped(el)) continue;
      out.push({ el: el });
    }

    var walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var node;
    while ((node = walker.nextNode())) {
      var parent = node.parentElement;
      if (parent && (shouldSkipElement(parent) || warnSkipped(parent))) continue;
      out.push({ node: node });
    }
    return out;
  }

  var queueItems = [];
  var drainScheduled = false;

  /** 空闲分片调度：优先 requestIdleCallback，不支持时退化为 setTimeout(0) */
  function idle(cb) {
    if (typeof window.requestIdleCallback === 'function') {
      window.requestIdleCallback(cb, { timeout: 200 });
    } else {
      setTimeout(cb, 0);
    }
  }

  /** 每次空闲片最多处理 BATCH_LIMIT 项，剩余自动续排，避免长时间占用主线程 */
  function drain() {
    drainScheduled = false;
    if (!state.enabled) {
      queueItems = [];
      return;
    }
    if (!queueItems.length) return;
    var budget = BATCH_LIMIT;
    state.applying = true;
    try {
      while (queueItems.length && budget > 0) {
        var it = queueItems.shift();
        budget -= 1;
        if (it.node) {
          if (!it.node.isConnected) continue;
          state.stats.nodes += 1;
          translateNode(it.node);
        } else if (it.el) {
          if (!it.el.isConnected) continue;
          translateAttrs(it.el);
        }
      }
    } finally {
      state.applying = false;
    }
    if (queueItems.length) {
      drainScheduled = true;
      idle(drain);
    }
  }

  function enqueue(root) {
    if (!state.enabled || !root) return 0;
    var before = queueItems.length;
    collect(root, queueItems);
    if (!drainScheduled && queueItems.length > before) {
      drainScheduled = true;
      idle(drain);
    }
    return queueItems.length - before;
  }

  function applyAll() {
    if (!state.enabled) return 0;
    queueItems = [];
    enqueue(document.body);
    return queueItems.length;
  }

  /** 把已翻译的文本节点与属性逐条还原为原文，并断开监听 */
  function restore() {
    if (state.observer) {
      state.observer.disconnect();
      state.observer = null;
    }
    queueItems = [];
    drainScheduled = false;
    if (document.body) {
      var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
      var node;
      while ((node = walker.nextNode())) {
        var rec = state.records.get(node);
        if (rec && rec.origin !== rec.output && node.nodeValue === rec.output) node.nodeValue = rec.origin;
      }
      var els = document.body.querySelectorAll('[placeholder], [title], [aria-label]');
      for (var i = 0; i < els.length; i++) {
        var store = state.attrRecords.get(els[i]);
        if (!store) continue;
        for (var name in store) {
          if (!Object.prototype.hasOwnProperty.call(store, name)) continue;
          var arec = store[name];
          if (arec.origin !== arec.output && els[i].getAttribute(name) === arec.output) {
            els[i].setAttribute(name, arec.origin);
          }
        }
      }
    }
    state.enabled = false;
    state.stats = { nodes: 0, translated: 0 };
  }

  function schedule(root) {
    if (!state.enabled) return;
    enqueue(root);
  }

  function start() {
    if (state.observer || !document.body) return;
    state.observer = new MutationObserver(function (records) {
      // 重入保护：自身改写触发的记录一律忽略，避免翻译→观察→再翻译的递归
      if (!state.enabled || state.applying) return;
      for (var i = 0; i < records.length; i++) {
        var rec = records[i];
        if (rec.type === 'childList') {
          for (var j = 0; j < rec.addedNodes.length; j++) {
            var node = rec.addedNodes[j];
            if (!node) continue;
            if (node.nodeType === 1) schedule(node);
            else if (node.nodeType === 3 && node.parentElement) schedule(node.parentElement);
          }
        } else if (rec.type === 'characterData') {
          // 页面（React）自行改写文本：就地重译，幂等自愈
          if (rec.target && rec.target.parentElement) translateNode(rec.target);
        }
      }
    });
    state.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  function summary() {
    return {
      enabled: state.enabled,
      level: state.level,
      patterns: state.patterns,
      dictSize: Object.keys(state.dict).length,
      translated: state.stats.translated,
      scanned: state.stats.nodes
    };
  }

  SELF.Localizer = {
    configure: configure,
    applyAll: applyAll,
    restore: restore,
    translate: translate,
    lookupById: lookupById,
    summary: summary,
    // 供单测观察内部状态
    _state: state,
    _drain: drain
  };
})();
