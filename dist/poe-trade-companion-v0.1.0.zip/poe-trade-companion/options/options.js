/**
 * options/options.js — 选项页逻辑（无第三方依赖）
 */
'use strict';

const DEFAULT_REMOTE_URL =
  'https://raw.githubusercontent.com/poe-trade-companion/poe-trade-companion/main/config/remote.json';

const DEFAULTS = {
  divineToChaos: 0,
  alertThreshold: 10,
  scanInterval: 30,
  shortcut: 'Ctrl+Shift+E',
  remoteConfigUrl: DEFAULT_REMOTE_URL,
  sidebarWidth: 420,
  autoExpand: false,
  sidebarEnabled: true,
  inlineBadge: true,
  floatingBall: true
};

const NUMBER_FIELDS = ['divineToChaos', 'alertThreshold', 'scanInterval', 'sidebarWidth'];
const TEXT_FIELDS = ['shortcut', 'remoteConfigUrl'];
const BOOL_FIELDS = ['inlineBadge', 'floatingBall', 'sidebarEnabled', 'autoExpand'];

const $ = (id) => document.getElementById(id);

function clamp(value, min, max, fallback) {
  const n = Number(value);
  if (!isFinite(n)) return fallback;
  return Math.min(max, Math.max(min, Math.round(n)));
}

function getSync(keys) {
  return new Promise((resolve) => chrome.storage.sync.get(keys, (got) => resolve(got || {})));
}

function setSync(obj) {
  return new Promise((resolve) => chrome.storage.sync.set(obj, () => resolve(true)));
}

function setStatus(text, kind) {
  const el = $('status');
  el.textContent = text;
  el.classList.remove('ok', 'warn');
  if (kind) el.classList.add(kind);
}

function fillForm(settings) {
  const s = Object.assign({}, DEFAULTS, settings);
  NUMBER_FIELDS.forEach((k) => {
    $(k).value = String(s[k] === undefined || s[k] === null ? DEFAULTS[k] : s[k]);
  });
  TEXT_FIELDS.forEach((k) => {
    $(k).value = s[k] == null ? DEFAULTS[k] : String(s[k]);
  });
  BOOL_FIELDS.forEach((k) => {
    $(k).checked = s[k] !== undefined ? !!s[k] : !!DEFAULTS[k];
  });
}

function readForm() {
  const out = {};
  NUMBER_FIELDS.forEach((k) => {
    out[k] = Number($(k).value);
  });
  TEXT_FIELDS.forEach((k) => {
    out[k] = String($(k).value || '').trim();
  });
  BOOL_FIELDS.forEach((k) => {
    out[k] = !!$(k).checked;
  });

  // 归一化与兜底
  out.divineToChaos = clamp(out.divineToChaos, 0, 100000, DEFAULTS.divineToChaos);
  out.alertThreshold = clamp(out.alertThreshold, 1, 90, DEFAULTS.alertThreshold);
  out.scanInterval = clamp(out.scanInterval, 1, 120, DEFAULTS.scanInterval);
  out.sidebarWidth = clamp(out.sidebarWidth, 320, 720, DEFAULTS.sidebarWidth);
  if (!out.shortcut) out.shortcut = '';
  if (out.remoteConfigUrl && !/^https?:\/\//i.test(out.remoteConfigUrl)) {
    out.remoteConfigUrl = '';
  }
  return out;
}

/* ------------------------------------------------------------------ 初始化 */

async function init() {
  $('ver').textContent = chrome.runtime.getManifest().version;
  const settings = await getSync(Object.keys(DEFAULTS));
  fillForm(settings);
  setStatus('修改后请点击「保存设置」，并刷新市集页面使界面配置生效。');
}

/* ------------------------------------------------------------------ 保存 */

$('btnSave').addEventListener('click', async () => {
  const settings = readForm();
  await setSync(settings);
  fillForm(settings);
  try {
    chrome.runtime.sendMessage({ type: 'ptc:set-alarm', minutes: settings.scanInterval }, () => {
      void chrome.runtime.lastError;
    });
  } catch (e) {
    /* 后台未响应时不影响已保存的设置 */
  }
  setStatus(
    '已保存。\n' +
      '· 汇率：' + (settings.divineToChaos > 0 ? '手动 ' + settings.divineToChaos : '自动（6 小时缓存）') + '\n' +
      '· 降价阈值：' + settings.alertThreshold + '%　检查间隔：' + settings.scanInterval + ' 分钟\n' +
      '· 侧栏宽度：' + settings.sidebarWidth + 'px　快捷键：' + (settings.shortcut || '未设置') + '\n' +
      '提示：已打开的市集页需刷新后才会应用界面相关改动。',
    'ok'
  );
});

/* ------------------------------------------------------------------ 重置 */

$('btnReset').addEventListener('click', async () => {
  fillForm(DEFAULTS);
  await setSync(DEFAULTS);
  try {
    chrome.runtime.sendMessage({ type: 'ptc:set-alarm', minutes: DEFAULTS.scanInterval }, () => {
      void chrome.runtime.lastError;
    });
  } catch (e) {
    /* ignore */
  }
  setStatus('已恢复默认设置。', 'ok');
});

/* -------------------------------------------------------------- 测试远端 */

$('btnTest').addEventListener('click', async () => {
  const url = String($('remoteConfigUrl').value || '').trim();
  if (!url) {
    setStatus('未填写远端配置 URL：将完全使用扩展内置选择器。', 'warn');
    return;
  }
  if (!/^https?:\/\//i.test(url)) {
    setStatus('URL 必须以 http:// 或 https:// 开头。', 'warn');
    return;
  }

  setStatus('正在拉取远端配置…');
  const res = await new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'ptc:get-remote-config', url, force: true }, (r) => {
        void chrome.runtime.lastError;
        resolve(r || null);
      });
    } catch (e) {
      resolve(null);
    }
  });

  if (!res || !res.ok || !res.config) {
    setStatus(
      '拉取失败：远端不可达、JSON 非法或字段校验未通过。\n扩展会自动回退到内置默认选择器，功能不受影响。',
      'warn'
    );
    return;
  }

  const cfg = res.config;
  const selectorKeys = cfg.selectors ? Object.keys(cfg.selectors) : [];
  const lines = [
    '拉取成功（来源：' + (res.source || 'remote') + '）。',
    '· schemaVersion：' + (cfg.schemaVersion != null ? cfg.schemaVersion : '-'),
    '· minExtensionVersion：' + (cfg.minExtensionVersion || '-'),
    '· 选择器覆盖项：' + (selectorKeys.length ? selectorKeys.join('、') : '无'),
    '· 搜索接口：' + ((cfg.api && cfg.api.searchPath) || '-'),
    '· 取样接口：' + ((cfg.api && cfg.api.fetchPath) || '-')
  ];
  if (cfg.notice) lines.push('· 公告：' + cfg.notice);
  if (res.savedAt) {
    const d = new Date(res.savedAt);
    lines.push('· 缓存时间：' + d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0') + ' ' + String(d.getHours()).padStart(2, '0') + ':' +
      String(d.getMinutes()).padStart(2, '0'));
  }
  lines.push('刷新市集页面后生效。');
  setStatus(lines.join('\n'), 'ok');
});

/* -------------------------------------------------------------- 清缓存 */

$('btnClearCache').addEventListener('click', async () => {
  const res = await new Promise((resolve) => {
    try {
      chrome.runtime.sendMessage({ type: 'ptc:clear-cache' }, (r) => {
        void chrome.runtime.lastError;
        resolve(r || null);
      });
    } catch (e) {
      resolve(null);
    }
  });
  if (res && res.ok) setStatus('已清空汇率缓存与远端配置缓存，下次使用时会重新拉取。', 'ok');
  else setStatus('清空失败：后台无响应，请重新加载扩展后再试。', 'warn');
});

/* ---------------------------------------------------- 双栏联动的小优化 */

$('sidebarEnabled').addEventListener('change', (e) => {
  if (!e.target.checked) {
    // 侧栏关闭时，浮动球与自动展开实际不再生效，仅做视觉提示
    setStatus('已关闭侧栏：保存后仅保留行内价格增强，浮动球与自动展开不再生效。', 'warn');
  } else {
    setStatus('已启用侧栏，保存后刷新页面即可看到入口。');
  }
});

init().catch((err) => setStatus('初始化异常：' + ((err && err.message) || '未知错误'), 'warn'));
