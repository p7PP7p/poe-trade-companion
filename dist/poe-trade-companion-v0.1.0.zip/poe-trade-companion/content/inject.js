/**
 * content/inject.js — MAIN world 数据层
 * hook window.fetch / XMLHttpRequest，拦截市集搜索与详情请求，
 * 并把结果通过 postMessage 交给 ISOLATED world 的 content.js。
 *
 * 所有 hook 均包 try/catch：扩展异常绝不能影响官网页面。
 */
(function () {
  'use strict';

  if (window.__PTC_INJECTED__) return;
  window.__PTC_INJECTED__ = true;

  const origFetch = window.fetch;
  const origXhrOpen = XMLHttpRequest.prototype.open;
  const origXhrSend = XMLHttpRequest.prototype.send;

  /** API 路径（可被 ISOLATED world 通过 postMessage 覆盖，以适配赛季改版） */
  const apiConfig = {
    searchPath: '/api/trade/search/',
    fetchPath: '/api/trade/fetch/'
  };

  const POST_LIMIT = 1.5 * 1024 * 1024; // 超过此体积走精简结构，避免拖慢页面

  function classify(url) {
    const u = String(url || '');
    try {
      if (u.indexOf(apiConfig.fetchPath) >= 0) return 'fetch';
      if (u.indexOf(apiConfig.searchPath) >= 0) return 'search';
    } catch (e) {
      return null;
    }
    return null;
  }

  function safeParseBody(body) {
    if (!body) return null;
    if (typeof body === 'object') {
      try {
        return JSON.parse(JSON.stringify(body));
      } catch (e) {
        return null;
      }
    }
    if (typeof body === 'string') {
      try {
        return JSON.parse(body);
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  function headersToObject(headers) {
    const out = {};
    try {
      if (!headers) return out;
      if (typeof headers.forEach === 'function') {
        headers.forEach((value, key) => {
          const k = String(key).toLowerCase();
          if (k.indexOf('x-rate-limit') === 0 || k === 'retry-after' || k === 'content-type') {
            out[k] = value;
          }
        });
        return out;
      }
      if (typeof headers === 'string') {
        headers.split(/\r?\n/).forEach((line) => {
          const idx = line.indexOf(':');
          if (idx < 0) return;
          const k = line.slice(0, idx).trim().toLowerCase();
          if (k.indexOf('x-rate-limit') === 0 || k === 'retry-after' || k === 'content-type') {
            out[k] = line.slice(idx + 1).trim();
          }
        });
      }
    } catch (e) {
      /* 拿不到头部时下发空对象 */
    }
    return out;
  }

  function xhrHeaders(xhr) {
    try {
      return headersToObject(xhr.getAllResponseHeaders ? xhr.getAllResponseHeaders() : '');
    } catch (e) {
      return {};
    }
  }

  /** 精简版响应（仅在体量过大时使用），保留扩展所需字段 */
  function slim(kind, payload) {
    try {
      if (kind === 'search') {
        return {
          id: payload.id,
          total: payload.total,
          result: Array.isArray(payload.result) ? payload.result : [],
          complexity: payload.complexity
        };
      }
      const list = Array.isArray(payload.result) ? payload.result : [];
      return {
        result: list.map((row) => ({
          id: row && row.id,
          item: row && row.item
            ? {
                name: row.item.name,
                typeLine: row.item.typeLine,
                icon: row.item.icon,
                explicitMods: row.item.explicitMods,
                frameType: row.item.frameType
              }
            : null,
          listing: row && row.listing
            ? {
                indexed: row.listing.indexed,
                price: row.listing.price,
                account: row.listing.account,
                whisper: row.listing.whisper
              }
            : null
        }))
      };
    } catch (e) {
      return null;
    }
  }

  function post(kind, url, request, response, headers) {
    try {
      let payload = response;
      try {
        if (JSON.stringify(response).length > POST_LIMIT) payload = slim(kind, response) || response;
      } catch (e) {
        /* stringify 失败时原样下发 */
      }
      window.postMessage(
        {
          source: 'ptc',
          type: 'trade-response',
          kind,
          url: String(url || ''),
          request: request || null,
          response: payload,
          headers: headers || {},
          at: Date.now()
        },
        '*'
      );
    } catch (e) {
      /* 消息通道异常不影响页面 */
    }
  }

  /* ------------------------- fetch hook ------------------------- */
  try {
    if (typeof origFetch === 'function') {
      window.fetch = function (input, init) {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        const kind = classify(url);

        let request = null;
        if (kind) {
          try {
            request = safeParseBody(init && init.body);
          } catch (e) {
            request = null;
          }
        }

        const promise = origFetch.apply(this, arguments);
        if (!kind) return promise;

        try {
          promise.then((res) => {
            try {
              const clone = res.clone();
              const headers = headersToObject(clone.headers);
              clone
                .json()
                .then((data) => post(kind, url, request, data, headers))
                .catch(() => {
                  /* 非 JSON 响应忽略 */
                });
            } catch (e) {
              /* clone 失败忽略 */
            }
          });
        } catch (e) {
          /* then 绑定失败忽略 */
        }
        return promise;
      };
    }
  } catch (e) {
    /* fetch 不可 hook 时静默降级 */
  }

  /* ------------------------- XHR hook ------------------------- */
  try {
    XMLHttpRequest.prototype.open = function (method, url) {
      try {
        this.__ptcMeta = { method: String(method || 'GET').toUpperCase(), url: String(url || '') };
      } catch (e) {
        /* ignore */
      }
      return origXhrOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
      try {
        const meta = this.__ptcMeta;
        const kind = meta && classify(meta.url);
        if (kind) {
          const request = safeParseBody(body);
          const xhr = this;
          xhr.addEventListener('load', function () {
            try {
              const text = xhr.responseText;
              let data = null;
              try {
                data = JSON.parse(text);
              } catch (e) {
                data = null;
              }
              if (data) post(kind, meta.url, request, data, xhrHeaders(xhr));
            } catch (e) {
              /* ignore */
            }
          });
        }
      } catch (e) {
        /* ignore */
      }
      return origXhrSend.apply(this, arguments);
    };
  } catch (e) {
    /* XHR 不可 hook 时静默降级 */
  }

  /* ------------- 接收 ISOLATED world 的指令（同一源 cookie） ------------- */
  window.addEventListener('message', function (event) {
    try {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.source !== 'ptc-cmd') return;

      if (data.cmd === 'config' && data.payload) {
        if (typeof data.payload.searchPath === 'string') apiConfig.searchPath = data.payload.searchPath;
        if (typeof data.payload.fetchPath === 'string') apiConfig.fetchPath = data.payload.fetchPath;
        return;
      }

      if (data.cmd === 'request' || data.cmd === 'search') {
        handleRequest(data.payload || {});
      }
    } catch (e) {
      /* ignore */
    }
  });

  async function handleRequest(payload) {
    const reqId = payload.reqId;
    const method = String(payload.method || 'GET').toUpperCase();
    let url = String(payload.url || '');
    try {
      url = new URL(url, location.origin).href;
    } catch (e) {
      /* 保留原始相对路径 */
    }

    const init = {
      method,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      }
    };
    if (method !== 'GET' && payload.body !== undefined && payload.body !== null) {
      init.body = JSON.stringify(payload.body);
    }

    try {
      const res = await origFetch.call(window, url, init);
      const headers = headersToObject(res.headers);
      let data = null;
      try {
        data = await res.json();
      } catch (e) {
        data = null;
      }
      reply({ reqId, ok: res.ok, status: res.status, data, headers });
    } catch (err) {
      reply({ reqId, ok: false, status: 0, error: String((err && err.message) || err), headers: {} });
    }
  }

  function reply(result) {
    try {
      window.postMessage(Object.assign({ source: 'ptc', type: 'trade-result' }, result), '*');
    } catch (e) {
      /* ignore */
    }
  }

  // 握手：让 content.js 确认 MAIN world 注入成功（Chrome <111 时可据此走 fallback）
  try {
    window.postMessage({ source: 'ptc', type: 'ready' }, '*');
  } catch (e) {
    /* ignore */
  }
})();
