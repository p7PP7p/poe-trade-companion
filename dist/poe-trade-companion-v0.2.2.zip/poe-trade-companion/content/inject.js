/**
 * content/inject.js — MAIN world 数据层
 * hook window.fetch / XMLHttpRequest，拦截市集搜索与详情请求，
 * 并把结果通过 postMessage 交给 ISOLATED world 的 content.js。
 *
 * 所有 hook 均包 try/catch：扩展异常绝不能影响官网页面。
 */
(function () {
  'use strict';

  if (window.__PTC_INJECTED__) return;
  window.__PTC_INJECTED__ = true;

  const origFetch = window.fetch;
  const origXhrOpen = XMLHttpRequest.prototype.open;
  const origXhrSend = XMLHttpRequest.prototype.send;

  /** API 路径（可被 ISOLATED world 通过 postMessage 覆盖，以适配赛季改版） */
  const apiConfig = {
    searchPath: '/api/trade/search/',
    fetchPath: '/api/trade/fetch/'
  };

  const POST_LIMIT = 1.5 * 1024 * 1024; // 超过此体积走精简结构，避免拖慢页面

  /* ---------------- 通道 A：数据层汉化（/api/trade/data/*） ---------------- */

  /** 数据层生效配置：内置 PTC_I18N + 远端/用户覆盖，由 ISOLATED world 下发 */
  const i18nConfig = {
    enabled: false,
    level: 'ui',
    patterns: true,
    dict: Object.create(null),
    dictLower: Object.create(null),
    patternsList: [],
    byId: Object.create(null),
    stats: { rewritten: 0, requests: 0 }
  };

  const DATA_PATH = '/api/trade/data/';
  const DATA_SEGMENTS = ['stats', 'items', 'static'];

  /** 识别数据接口：stats / items / static / other，非数据接口返回 null */
  function classifyData(url) {
    const u = String(url || '');
    if (u.indexOf(DATA_PATH) < 0) return null;
    for (let i = 0; i < DATA_SEGMENTS.length; i++) {
      if (u.indexOf(DATA_PATH + DATA_SEGMENTS[i]) >= 0) return DATA_SEGMENTS[i];
    }
    return 'other';
  }

  /** 页面本身已配置中文时不再二次翻译 */
  function pageAlreadyLocalized() {
    try {
      const lang = (document.documentElement && document.documentElement.getAttribute('lang')) || '';
      return /^zh/i.test(lang);
    } catch (e) {
      return false;
    }
  }

  function mergePlain(target, src) {
    if (!src) return;
    for (const k in src) {
      if (typeof src[k] === 'string') target[k] = src[k];
    }
  }

  function buildI18n(payload) {
    const builtin = (typeof window.PTC_I18N === 'object' && window.PTC_I18N) || {};
    const level = payload && payload.level === 'full' ? 'full' : 'ui';
    const dict = Object.create(null);
    // 数据层与 DOM 层保持同一档位语义：ui 只叠界面级词库，full 才叠全量
    if (level === 'full') {
      mergePlain(dict, builtin.dict);
      mergePlain(dict, builtin.fullDict);
    } else {
      mergePlain(dict, builtin.uiDict);
      mergePlain(dict, builtin.dict);
    }
    mergePlain(dict, payload && payload.dict);
    const lower = Object.create(null);
    for (const k in dict) lower[k.toLowerCase()] = dict[k];

    i18nConfig.level = level;
    i18nConfig.dict = dict;
    i18nConfig.dictLower = lower;
    i18nConfig.patterns = !payload || payload.patterns !== false;
    i18nConfig.patternsList = Array.isArray(builtin.patterns) ? builtin.patterns : [];
    i18nConfig.byId = Object.create(null);
    mergePlain(i18nConfig.byId, builtin.byId);
    mergePlain(i18nConfig.byId, payload && payload.byId);
    i18nConfig.enabled = !!(payload && payload.enabled);
    if (i18nConfig.enabled && pageAlreadyLocalized()) i18nConfig.enabled = false;
  }

  function translateText(text) {
    if (!i18nConfig.enabled) return null;
    const core = String(text).replace(/[\s\u00a0]+/g, ' ').trim();
    if (!core) return null;
    if (/[\u4e00-\u9fff]/.test(core)) return null;
    if (!/[A-Za-z]{2}/.test(core)) return null;
    const hit = i18nConfig.dict[core];
    if (hit !== undefined) return hit;
    const low = i18nConfig.dictLower[core.toLowerCase()];
    if (low !== undefined) return low;
    if (i18nConfig.patterns) {
      for (let i = 0; i < i18nConfig.patternsList.length; i++) {
        const p = i18nConfig.patternsList[i];
        if (!p || !p.re) continue;
        const m = core.match(p.re);
        if (!m) continue;
        if (typeof p.fn === 'function') {
          const fnOut = p.fn(m);
          if (fnOut) return fnOut;
          continue;
        }
        const tpl = typeof p.tpl === 'string' ? p.tpl : (typeof p.replace === 'string' ? p.replace : '');
        if (!tpl) continue;
        // $n 参数优先用词条翻译；残留英文且模板未标记 allowEnglish 时放弃（不出半中半英）
        const out = tpl.replace(/\$(\d+)/g, (_, n) => {
          const v = m[Number(n)];
          if (v === undefined || v === null) return '';
          const pHit = i18nConfig.dict[v] !== undefined ? i18nConfig.dict[v] : i18nConfig.dictLower[v.toLowerCase()];
          return pHit === undefined ? v : pHit;
        });
        if (!out || out === core) continue;
        if (!p.allowEnglish && /[A-Za-z]{2,}/.test(out)) continue;
        return out;
      }
    }
    return null;
  }

  /** 只改词典能命中的展示字段；枚举值（如 armour.chest）不在词典中，天然不受影响 */
  // label/title 为筛选器分组标题（如 "Item Category"），text 为选项文案；type 等枚举值天然不在词典中
  const TEXT_FIELDS = ['label', 'title', 'text', 'type'];

  function rewriteEntry(entry, stats) {
    const keyId = typeof entry.id === 'string' ? entry.id : '';
    for (let i = 0; i < TEXT_FIELDS.length; i++) {
      const field = TEXT_FIELDS[i];
      const val = entry[field];
      if (typeof val !== 'string' || !val) continue;
      const byIdHit = keyId && field === 'text' ? i18nConfig.byId[keyId] : null;
      const zh = byIdHit || translateText(val);
      if (!zh || zh === val) continue;
      entry[field] = zh;
      stats.rewritten += 1;
    }
  }

  function walkI18n(node, stats, depth) {
    if (!node || depth > 6) return;
    if (Array.isArray(node)) {
      for (let i = 0; i < node.length; i++) walkI18n(node[i], stats, depth + 1);
      return;
    }
    if (typeof node !== 'object') return;
    // 每个层级都尝试改写展示字段：分组对象也可能只有 label（如 "Item Category"）而无 text
    rewriteEntry(node, stats);
    for (const k in node) {
      if (!Object.prototype.hasOwnProperty.call(node, k)) continue;
      // 图标/私聊原文/角色名不属于界面文案，绝不改写
      if (k === 'icon' || k === 'whisper' || k === 'name') continue;
      const v = node[k];
      if (v && typeof v === 'object') walkI18n(v, stats, depth + 1);
    }
  }

  function localizePayload(payload) {
    const stats = { rewritten: 0 };
    try {
      i18nConfig.stats.requests += 1;
      if (!i18nConfig.enabled) return { payload, changed: 0 };
      walkI18n(payload, stats, 0);
      i18nConfig.stats.rewritten += stats.rewritten;
    } catch (e) {
      return { payload, changed: 0 };
    }
    return { payload, changed: stats.rewritten };
  }

  /** 用改写后的 Response 替换原响应；去掉 content-length/content-encoding 避免与新体积冲突 */
  function localizeResponse(res) {
    try {
      if (!res || !res.ok) return res;
      const clone = res.clone();
      return clone
        .json()
        .then((data) => {
          const out = localizePayload(data);
          if (!out.changed) return res;
          const headers = new Headers();
          try {
            res.headers.forEach((v, k) => {
              const key = String(k).toLowerCase();
              if (key === 'content-length' || key === 'content-encoding') return;
              headers.set(k, v);
            });
          } catch (e) {
            /* header 拷贝失败则用空头 */
          }
          return new Response(JSON.stringify(out.payload), {
            status: res.status,
            statusText: res.statusText,
            headers
          });
        })
        .catch(() => res);
    } catch (e) {
      return res;
    }
  }

  function classify(url) {
    const u = String(url || '');
    try {
      if (u.indexOf(apiConfig.fetchPath) >= 0) return 'fetch';
      if (u.indexOf(apiConfig.searchPath) >= 0) return 'search';
    } catch (e) {
      return null;
    }
    return null;
  }

  function safeParseBody(body) {
    if (!body) return null;
    if (typeof body === 'object') {
      try {
        return JSON.parse(JSON.stringify(body));
      } catch (e) {
        return null;
      }
    }
    if (typeof body === 'string') {
      try {
        return JSON.parse(body);
      } catch (e) {
        return null;
      }
    }
    return null;
  }

  function headersToObject(headers) {
    const out = {};
    try {
      if (!headers) return out;
      if (typeof headers.forEach === 'function') {
        headers.forEach((value, key) => {
          const k = String(key).toLowerCase();
          if (k.indexOf('x-rate-limit') === 0 || k === 'retry-after' || k === 'content-type') {
            out[k] = value;
          }
        });
        return out;
      }
      if (typeof headers === 'string') {
        headers.split(/\r?\n/).forEach((line) => {
          const idx = line.indexOf(':');
          if (idx < 0) return;
          const k = line.slice(0, idx).trim().toLowerCase();
          if (k.indexOf('x-rate-limit') === 0 || k === 'retry-after' || k === 'content-type') {
            out[k] = line.slice(idx + 1).trim();
          }
        });
      }
    } catch (e) {
      /* 拿不到头部时下发空对象 */
    }
    return out;
  }

  function xhrHeaders(xhr) {
    try {
      return headersToObject(xhr.getAllResponseHeaders ? xhr.getAllResponseHeaders() : '');
    } catch (e) {
      return {};
    }
  }

  /** 精简版响应（仅在体量过大时使用），保留扩展所需字段 */
  function slim(kind, payload) {
    try {
      if (kind === 'search') {
        return {
          id: payload.id,
          total: payload.total,
          result: Array.isArray(payload.result) ? payload.result : [],
          complexity: payload.complexity
        };
      }
      const list = Array.isArray(payload.result) ? payload.result : [];
      return {
        result: list.map((row) => ({
          id: row && row.id,
          item: row && row.item
            ? {
                name: row.item.name,
                typeLine: row.item.typeLine,
                icon: row.item.icon,
                explicitMods: row.item.explicitMods,
                frameType: row.item.frameType
              }
            : null,
          listing: row && row.listing
            ? {
                indexed: row.listing.indexed,
                price: row.listing.price,
                account: row.listing.account,
                whisper: row.listing.whisper
              }
            : null
        }))
      };
    } catch (e) {
      return null;
    }
  }

  function post(kind, url, request, response, headers) {
    try {
      let payload = response;
      try {
        if (JSON.stringify(response).length > POST_LIMIT) payload = slim(kind, response) || response;
      } catch (e) {
        /* stringify 失败时原样下发 */
      }
      window.postMessage(
        {
          source: 'ptc',
          type: 'trade-response',
          kind,
          url: String(url || ''),
          request: request || null,
          response: payload,
          headers: headers || {},
          at: Date.now()
        },
        '*'
      );
    } catch (e) {
      /* 消息通道异常不影响页面 */
    }
  }

  /* ------------------------- fetch hook ------------------------- */
  try {
    if (typeof origFetch === 'function') {
      window.fetch = function (input, init) {
        const url = typeof input === 'string' ? input : (input && input.url) || '';
        const kind = classify(url);

        let request = null;
        if (kind) {
          try {
            request = safeParseBody(init && init.body);
          } catch (e) {
            request = null;
          }
        }

        const promise = origFetch.apply(this, arguments);

        // 通道 A：筛选器词条数据接口，改写 text 字段后再交回页面
        if (classifyData(url)) return localizeResponse(promise);

        if (!kind) return promise;

        try {
          promise.then((res) => {
            try {
              const clone = res.clone();
              const headers = headersToObject(clone.headers);
              clone
                .json()
                .then((data) => post(kind, url, request, data, headers))
                .catch(() => {
                  /* 非 JSON 响应忽略 */
                });
            } catch (e) {
              /* clone 失败忽略 */
            }
          });
        } catch (e) {
          /* then 绑定失败忽略 */
        }
        return promise;
      };
    }
  } catch (e) {
    /* fetch 不可 hook 时静默降级 */
  }

  /* ------------------------- XHR hook ------------------------- */
  try {
    XMLHttpRequest.prototype.open = function (method, url) {
      try {
        this.__ptcMeta = { method: String(method || 'GET').toUpperCase(), url: String(url || '') };
      } catch (e) {
        /* ignore */
      }
      return origXhrOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
      try {
        const meta = this.__ptcMeta;
        const kind = meta && classify(meta.url);
        if (kind) {
          const request = safeParseBody(body);
          const xhr = this;
          xhr.addEventListener('load', function () {
            try {
              const text = xhr.responseText;
              let data = null;
              try {
                data = JSON.parse(text);
              } catch (e) {
                data = null;
              }
              if (data) post(kind, meta.url, request, data, xhrHeaders(xhr));
            } catch (e) {
              /* ignore */
            }
          });
        }
      } catch (e) {
        /* ignore */
      }
      return origXhrSend.apply(this, arguments);
    };
  } catch (e) {
    /* XHR 不可 hook 时静默降级 */
  }

  /* ------------- 接收 ISOLATED world 的指令（同一源 cookie） ------------- */
  window.addEventListener('message', function (event) {
    try {
      if (event.source !== window) return;
      const data = event.data;
      if (!data || data.source !== 'ptc-cmd') return;

      if (data.cmd === 'config' && data.payload) {
        if (typeof data.payload.searchPath === 'string') apiConfig.searchPath = data.payload.searchPath;
        if (typeof data.payload.fetchPath === 'string') apiConfig.fetchPath = data.payload.fetchPath;
        return;
      }

      if (data.cmd === 'request' || data.cmd === 'search') {
        handleRequest(data.payload || {});
      }
    } catch (e) {
      /* ignore */
    }
  });

  async function handleRequest(payload) {
    const reqId = payload.reqId;
    const method = String(payload.method || 'GET').toUpperCase();
    let url = String(payload.url || '');
    try {
      url = new URL(url, location.origin).href;
    } catch (e) {
      /* 保留原始相对路径 */
    }

    const init = {
      method,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'X-Requested-With': 'XMLHttpRequest'
      }
    };
    if (method !== 'GET' && payload.body !== undefined && payload.body !== null) {
      init.body = JSON.stringify(payload.body);
    }

    try {
      const res = await origFetch.call(window, url, init);
      const headers = headersToObject(res.headers);
      let data = null;
      try {
        data = await res.json();
      } catch (e) {
        data = null;
      }
      reply({ reqId, ok: res.ok, status: res.status, data, headers });
    } catch (err) {
      reply({ reqId, ok: false, status: 0, error: String((err && err.message) || err), headers: {} });
    }
  }

  function reply(result) {
    try {
      window.postMessage(Object.assign({ source: 'ptc', type: 'trade-result' }, result), '*');
    } catch (e) {
      /* ignore */
    }
  }

  /* ------------- 汉化配置下发（ISOLATED world → MAIN world） ------------- */
  try {
    window.addEventListener('message', (ev) => {
      try {
        if (ev.source !== window) return;
        const data = ev.data;
        if (!data || data.source !== 'ptc-cmd' || data.cmd !== 'i18n') return;
        buildI18n(data.payload || {});
        window.postMessage(
          {
            source: 'ptc',
            type: 'i18n-ready',
            payload: {
              enabled: i18nConfig.enabled,
              level: i18nConfig.level,
              dictSize: Object.keys(i18nConfig.dict).length
            }
          },
          '*'
        );
      } catch (e) {
        /* ignore */
      }
    });
  } catch (e) {
    /* ignore */
  }

  // 先载入内置词典（默认关闭，等 content.js 下发开关）
  try {
    buildI18n({ enabled: false });
  } catch (e) {
    /* ignore */
  }

  // 调试/自测入口（只读）
  try {
    window.__PTC_DATA_HOOK__ = {
      config: i18nConfig,
      translate: translateText,
      classifyData,
      localizePayload
    };
  } catch (e) {
    /* ignore */
  }

  // 握手：让 content.js 确认 MAIN world 注入成功（Chrome <111 时可据此走 fallback）
  try {
    window.postMessage({ source: 'ptc', type: 'ready' }, '*');
  } catch (e) {
    /* ignore */
  }
})();
